﻿angular .module('MyApp', ['ngMaterial', 'ngMessages', 'material.svgAssetsCache']) .controller('DemoCtrl', function($scope) {
    $scope.user = {
      name: 'John Doe',
      email: '',
      phone: '',
      address: 'Mountain View, CA',
      donation: 19.99
    };
  });
